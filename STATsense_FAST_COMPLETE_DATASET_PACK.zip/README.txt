STATsense / SIH26101 FAST DATA COLLECTION PACK
Generated for rapid prototype work.

CONTENTS
01 official SIH26101 competency taxonomy
02 NSSTA source-derived training catalogue/topics
03 NSSTA/MoSPI FY2025-26 calendar rows verified from indexed official material (PARTIAL)
04 MoSPI/eSankhyiki dataset families relevant to official statistics
05 official source registry
06 derived course->competency mapping (CURATED, NOT OFFICIAL)
07 synthetic learner competency profiles (DEMO DATA, NOT GOVERNMENT EMPLOYEE DATA)
08 synthetic skill-gap records for prototype/demo

IMPORTANT
- The SIH problem statement names nssta.gov.in and mospi.gov.in as dataset links; it does not provide one single employee-competency CSV.
- iGOT publicly documents AI-driven role/competency mapping and course recommendations. Therefore STATsense should not claim those functions are unique by themselves.
- Use the closed-loop evidence-based reassessment, source-grounded quiz generation, explainable gap view, and adapter architecture as differentiation.
- Do not claim live iGOT API access unless an authorized integration is actually available.
- Do not use real employee PII for the prototype. Synthetic profiles are included for demo purposes.
- MoSPI GSDD 2026 distinguishes open, registered, restricted, and non-shareable data. Respect those access conditions.
- Raw eSankhyiki/microdata downloads may require portal-specific access. This pack captures the relevant official catalogue/source layer without pretending that every underlying dataset has been downloaded.
